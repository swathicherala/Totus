<template>
  <div id="app">
    <NavigationPage />
    <!-- <CarousalImage/> -->
    <!-- <WelcomePage/> -->
    <FooterPage/>
  </div>
</template>

<script>
import NavigationPage from './components/NavigationPage.vue'
// import CarousalImage from './components/CarousalImage.vue'
// import WelcomePage from './components/WelcomePage.vue'
import FooterPage from './components/FooterPage.vue'

export default {
  name: 'App',
  components: {
    NavigationPage,
    // CarousalImage,
    // WelcomePage,
    FooterPage
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
