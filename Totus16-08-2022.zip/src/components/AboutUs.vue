<template>
    <div class="main">
        <div class="about">
            <h1>
                Outstanding quality, competitive costs, fast completion…
            </h1>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                 <h1>
                    Why Choose Totus?
                 </h1>
                 <p>
                    Totus is a family-run company that has grown organically into a large professional team of skilled tradesmen. We maintain the highest quality of work by only using our own team and partnering with leading London and Surrey architectural, surveyor, design and engineering companies.
                 </p>
                </div>
                <div class="col-md-6">
                    <p>
                        Most of our work comes through customer and professional referrals. This is due to a combination of making sure we truly understand clients’ needs, whilst providing the finest finish through attention to detail and quality workmanship. Every project is personally managed by our directors Andrew or Terry who collaborate with all parties involved to ensure progress is being made until successful and timely completion.
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
.about{
  background-color: #7a8e8d;
  text-align: left;
  padding:80px;
  margin-bottom:40px;
}
.main{
        display:block
}
</style>