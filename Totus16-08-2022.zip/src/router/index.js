import Vue from 'vue'
import VueRouter from 'vue-router'
import HomePage from '../components/HomePage.vue'
import ServicesPage from '../components/ServicesPage.vue'
import AboutUs from '../components/AboutUs.vue'
// import UpdateData from '../components/UpdateData.vue'
// import UserData from '../components/UserData.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomePage
  },
  {
    path: '/services',
    name: 'services',
    component:ServicesPage
  },
  {
    path: '/about',
    name: 'about',
    component:AboutUs
  },
  // {
  //   path: '/update',
  //   name: 'update',
  //   component:UpdateData
  // },
  // {
  //   path: '/userdata',
  //   name: 'userdata',
  //   component:UserData
  // },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
